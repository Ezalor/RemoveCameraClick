# 删除拍照和截图声音
删除 camera_click.ogg。
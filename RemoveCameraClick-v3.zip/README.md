# 删除拍照和截图声音
删除 camera_click.ogg。

##更新日志
v3
    - 同步更新（模板 v3）
v2
    - 同步更新（Magisk v10）
v1
    - 第一版
